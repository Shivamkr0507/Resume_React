import React from "react";

export const EducationContext = React.createContext(); 