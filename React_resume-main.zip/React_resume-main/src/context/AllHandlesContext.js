import React from "react";

export const AllHandlesContext = React.createContext(); 