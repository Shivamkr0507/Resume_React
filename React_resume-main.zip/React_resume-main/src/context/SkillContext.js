import React from "react";

export const SkillContext = React.createContext(); 