import React from "react";

export const NavBarContext = React.createContext(); 