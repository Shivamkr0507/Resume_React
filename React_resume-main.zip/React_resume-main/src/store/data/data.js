export const NavBar = [
    {
        id: 1,
        name: "HOME",
        link: "#Home",
        color: "text-black"
    },
    {
        id: 2,
        name: "ABOUT ME",
        link: "#AboutMe",
        color: "text-black"
    },
    {
        id: 3,
        name: "EDUCATION",
        link: "#Education",
        color: "text-black"
    },
    {
        id: 4,
        name: "PROJECTS",
        link: "#Project",
        color: "text-black"
    },
    { 
        id: 5,
        name: 'WORK EXPERIENCE', 
        link: '#Work', 
        color: 'text-black' },
    {
        id: 6,
        name: "CONTACT",
        link: "#Contact",
        color: "text-black"
    }
]
